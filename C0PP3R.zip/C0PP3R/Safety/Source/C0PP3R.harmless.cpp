#include <windows.h>

DWORD WINAPI cur(LPVOID lpParam) {
    POINT cursor;
    while(1) {
        HDC hdc = GetDC(HWND_DESKTOP);
        int icon_x = GetSystemMetrics(SM_CXICON);
        int icon_y = GetSystemMetrics(SM_CYICON);
        GetCursorPos(&cursor);
        DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(NULL, IDI_WARNING));
        ReleaseDC(0, hdc);
    }
    return(1);
}

DWORD WINAPI payloadGDI1(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while(1) {
        HDC hdc = GetDC(0);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, 0x1900ac010e);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
   }
}

DWORD WINAPI payloadGDI2(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 666, rand() % 666, w, h, hdc, rand() % 666, rand() % 666, NOTSRCERASE);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI payloadGDI3(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while(1) {
        HDC hdc = GetDC(0);
        BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI payloadGDI4(LPVOID lpParam) {
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    while(1) {
        HDC hdc = GetDC(0);
        POINT p[4] = { rand() % sw, rand() % sh, rand() % sw, rand() % sh, rand() % sw, rand() % sh };
        HPEN hPen = CreatePen(PS_SOLID, 5, RGB(255, 0, 255));
        SelectObject(hdc, hPen);
        PolyBezier(hdc, p, 4);
        DeleteObject(hPen);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI payloadGDI5(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int x = GetSystemMetrics(0);
        int y = GetSystemMetrics(1);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        Pie(hdc, rand() % x, rand() % y, rand() % x, rand() % y, rand() % x, rand() % y, rand() % x, rand() % y);
        DeleteObject(brush);
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    if (MessageBoxW(NULL, L"Run Malware?", L"C0PP3R.harmless.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"Are you sure you want to execute this?\nIt will make your computer unbootable", L"C0PP3R.harmless.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            MessageBoxW(NULL, L"AMOGUSAMOGUSAMOGUSAMOGUSAMOGUSAMOGUSAMOGUSAMOGUSAMOGUSAMOGUSAMOGUS", L"AMOGUSAMOGUSAMOGUSAMOGUSAMOGUS", MB_OK | MB_ICONERROR);
            Sleep(5000);
            HANDLE thread1dot0 = CreateThread(0, 0, cur, 0, 0, 0);
            HANDLE thread1 = CreateThread(0, 0, payloadGDI1, 0, 0, 0);
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            Sleep(100);
            HANDLE thread2 = CreateThread(0, 0, payloadGDI2, 0, 0, 0);
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(100);
            HANDLE thread3 = CreateThread(0, 0, payloadGDI3, 0, 0, 0);
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            Sleep(100);
            HANDLE thread4 = CreateThread(0, 0, payloadGDI4, 0, 0, 0);
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(100);
            HANDLE thread5 = CreateThread(0, 0, payloadGDI5, 0, 0, 0);
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
        }
    }
}