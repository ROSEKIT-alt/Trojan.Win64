//WARNING: THIS IS A SAFETY TROJAN!
#include <windows.h>
#include <cmath>
//typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
//typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

DWORD WINAPI icons(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int x = rand() % GetSystemMetrics(0);
        int y = rand() % GetSystemMetrics(1);
        DrawIcon(hdc, x, y, LoadIcon(0, IDI_ERROR));
        DrawIcon(hdc, x, y, LoadIcon(0, IDI_WARNING));
        DrawIcon(hdc, x, y, LoadIcon(0, IDI_APPLICATION));
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI payload(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCINVERT);
        StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCINVERT);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI textz(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sx = GetSystemMetrics(0);
        int sy = GetSystemMetrics(1);
        LPCWSTR lpText = L"SKID!";
        SetBkColor(hdc, RGB(0, 0, 0));
        SetTextColor(hdc, RGB(0, 255, 0));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
    }
}

DWORD WINAPI masher(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 5, rand() % 5, rand() % sw, rand() % sh, hdc, rand() % 5, rand() % 5, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}

VOID WINAPI ci(int x, int y, int w, int h) {
   HDC hdc = GetDC(0);
   HRGN hrgn = CreateEllipticRgn(x, y, w + x, h + y);
   SelectClipRgn(hdc, hrgn);
   BitBlt(hdc, x, y, w, h, hdc, x, y, NOTSRCCOPY);
   DeleteObject(hrgn);
   ReleaseDC(0, hdc);
}

DWORD WINAPI wef(LPVOID lpParam) {
    RECT rect;
    GetWindowRect(GetDesktopWindow(), &rect);
    int w = rect.right - rect.left - 500;
    int h = rect.bottom - rect.top - 500;
    for (int t = 0;; t++) {
         const int size = 1000;
         int x = rand() % (w + size) - size / 2;
         int y = rand() % (h + size) - size / 2;
         for (int i = 0; i < size; i += 100) {
              ci(x - i / 2, y - i / 2, i, i);
              Sleep(10);
         }
    }
}

DWORD WINAPI sines(LPVOID lpParam) {
    while(1) {
       HDC hdc = GetDC(0);
       int sw = GetSystemMetrics(0);
       int sh = GetSystemMetrics(1);
       double angle = 0;
       for (float i = 0; i < sw + sh; i += 0.99f) {
            hdc = GetDC(0);
            int a = sin(angle) * 20;
            BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCCOPY);
            angle += M_PI / 40;
            DeleteObject(&a);
            DeleteObject(&i);
       }
       ReleaseDC(0, hdc);
       DeleteDC(hdc);
       DeleteObject(&sw);
       DeleteObject(&sh);
       DeleteObject(&angle);
    }
}

DWORD WINAPI patblt(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int x = GetSystemMetrics(0);
        int y = GetSystemMetrics(1);
        HBRUSH brush = CreateSolidBrush(RGB(0, 255, 255));
        SelectObject(hdc, brush);
        PatBlt(hdc, 0, 0, x, y, PATINVERT);
        ReleaseDC(0, hdc);
        DeleteObject(brush);
        Sleep(10);
    }
}

DWORD WINAPI sh(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 10, rand() % 10, sw, sh, hdc, rand() % 10, rand() % 10, SRCINVERT);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI cur(LPVOID lpParam) {
    POINT cursor;
    while(1) {
        HDC hdc = GetDC(0);
        int icon_x = GetSystemMetrics(SM_CXICON);
        int icon_y = GetSystemMetrics(SM_CYICON);
        GetCursorPos(&cursor);
        int x = cursor.x + rand() % 3 - 1;
        int y = cursor.y + rand() % 3 - 1;
        SetCursorPos(x, y);
        DrawIcon(hdc, cursor.x - icon_x, cursor.y - icon_y, LoadIcon(0, IDI_ERROR));
        ReleaseDC(0, hdc);
    }
    return(1);
}

VOID WINAPI sound1() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(t*(322376503>>(t>>13&27)&127)|t>>4|t<<5);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>((9*t&t>>4|5*t&t>>7|3*t&t>>10)-1);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(20*t*t*(t>>11)/7);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound4() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(t*((t>>9|t>>13)&15)&129);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>((t&5*t|t>>4)+(t|t>>4*t<<7)^t>>12);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound6() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>((t*(t>>13|t>>8)|t>>16^t)-64);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

int main() {
    if (MessageBoxW(NULL, L"This software is malware, do you wish to run this?", L"YDFGH-safety.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"Are you sure? Please backup your important files before running it\nGood Luck :)", L"YDFGH-safety.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            Sleep(2000);
            HANDLE thread1 = CreateThread(0, 0, payload, 0, 0, 0);
            HANDLE thread1dot0 = CreateThread(0, 0, icons, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            TerminateThread(thread1dot0, 0);
            CloseHandle(thread1dot0);
            Sleep(100);
            HANDLE thread2 = CreateThread(0, 0, textz, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(100);
            HANDLE thread3 = CreateThread(0, 0, masher, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            Sleep(100);
            HANDLE thread4 = CreateThread(0, 0, wef, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(100);
            HANDLE thread5 = CreateThread(0, 0, patblt, 0, 0, 0);
            HANDLE thread5dot1 = CreateThread(0, 0, sines, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            TerminateThread(thread5dot1, 0);
            CloseHandle(thread5dot1);
            Sleep(100);
            HANDLE thread6 = CreateThread(0, 0, sh, 0, 0, 0);
            HANDLE thread6dot2 = CreateThread(0, 0, cur, 0, 0, 0);
            sound6();
            Sleep(30000);
            TerminateThread(thread6, 0);
            CloseHandle(thread6);
            TerminateThread(thread6dot2, 0);
            CloseHandle(thread6dot2);
        }
    }
}